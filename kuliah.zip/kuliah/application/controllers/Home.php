<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->library('session');
        if(!$this->session->userdata('user')) redirect('auth/login');
    }
    public function index(){
        $user = $this->session->userdata('user');
        if($user['role']=='admin') redirect('admin');
        if($user['role']=='mahasiswa') redirect('mahasiswa');
        if($user['role']=='dosen') redirect('dosen');
        $this->load->view('home');
    }
}
