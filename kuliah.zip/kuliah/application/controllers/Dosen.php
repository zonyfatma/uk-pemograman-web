<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('DosenModel');
        $this->load->model('Nilai_mutu_model');
        $this->load->library('session');
    }

    public function dashboard() {
        $user = $this->session->userdata('user');
        $nidn = isset($user['ref_nidn']) ? $user['ref_nidn'] : null;
        $data['title'] = "Dashboard Dosen";
        $data['jadwal'] = $this->DosenModel->getJadwalByDosen($nidn);

        $this->load->view('templates/header', $data);
        $this->load->view('dosen/dashboard', $data);
        $this->load->view('templates/footer');
    }

    public function nilai($id_jadwal) {
        $data['title'] = "Input Nilai Mahasiswa";
        $data['mahasiswa'] = $this->DosenModel->getMahasiswaByJadwal($id_jadwal);
        $data['id_jadwal'] = $id_jadwal;
        $data['nilai_huruf'] = $this->Nilai_mutu_model->get_all();

        $this->load->view('templates/header', $data);
        $this->load->view('dosen/nilai', $data);
        $this->load->view('templates/footer');
    }

    

    public function simpanNilai() {
        $nilai = $this->input->post('nilai');
        foreach ($nilai as $id_rencana_studi => $data) {
            $this->DosenModel->updateNilai(
                $id_rencana_studi,
                $data['angka'],
                $data['huruf']
            );
        }

        $this->session->set_flashdata('success', 'Nilai berhasil disimpan!');
        redirect('dosen/dashboard');
    }
}
