<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('role') !== 'admin') {
            redirect('auth');
        }
        $this->load->model('Dosen_model');
        $this->load->helper('url');
    }

    // Halaman utama daftar dosen
    public function index()
    {
        $data['dosen'] = $this->Dosen_model->get_all();
        $this->load->view('admin/dosen', $data);
    }

    // Tambah data dosen
    public function tambah()
    {
        $nidn = $this->input->post('nidn');
        $nama = $this->input->post('nama');

        $data = [
            'nidn' => $nidn,
            'nama' => $nama
        ];

        $this->Dosen_model->insert($data);
        redirect('admin/dosen');
    }

    // Edit data dosen
    public function edit($nidn)
    {
        $data['dsn'] = $this->Dosen_model->get_by_id($nidn);
        $this->load->view('admin/dosen_edit', $data);
    }

    // Update data dosen
    public function update()
    {
        $nidn = $this->input->post('nidn');
        $nama = $this->input->post('nama');

        $data = ['nama' => $nama];
        $this->Dosen_model->update($nidn, $data);
        redirect('admin/dosen');
    }

    // Hapus data dosen
    public function hapus($nidn)
    {
        $this->Dosen_model->delete($nidn);
        redirect('admin/dosen');
    }
}
