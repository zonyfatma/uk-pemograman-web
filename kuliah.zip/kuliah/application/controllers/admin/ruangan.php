<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ruangan extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('role') !== 'admin') {
            redirect('auth');
        }
        $this->load->model('Ruangan_model');
        $this->load->helper('url');
    }

    // Halaman utama daftar ruangan
    public function index()
    {
        $data['ruangan'] = $this->Ruangan_model->get_all();
        $this->load->view('admin/ruangan', $data);
    }

    // Tambah ruangan baru
    public function tambah()
    {
        $nama_ruangan = $this->input->post('nama_ruangan');

        $data = ['nama_ruangan' => $nama_ruangan];
        $this->Ruangan_model->insert($data);
        redirect('admin/ruangan');
    }

    // Edit ruangan
    public function edit($id)
    {
        $data['rgn'] = $this->Ruangan_model->get_by_id($id);
        $this->load->view('admin/ruangan_edit', $data);
    }

    // Update ruangan
    public function update()
    {
        $id = $this->input->post('id_ruangan');
        $nama_ruangan = $this->input->post('nama_ruangan');

        $data = ['nama_ruangan' => $nama_ruangan];
        $this->Ruangan_model->update($id, $data);
        redirect('admin/ruangan');
    }

    // Hapus ruangan
    public function hapus($id)
    {
        $this->Ruangan_model->delete($id);
        redirect('admin/ruangan');
    }
}
