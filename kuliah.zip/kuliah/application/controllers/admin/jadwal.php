<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jadwal extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('role') !== 'admin') {
            redirect('auth');
        }
        $this->load->model('Jadwal_model');
        $this->load->helper('url');
    }

    // Halaman utama jadwal
    public function index()
    {
        $data['jadwal'] = $this->Jadwal_model->get_all();
        $data['mata_kuliah'] = $this->Jadwal_model->get_mata_kuliah();
        $data['dosen'] = $this->Jadwal_model->get_dosen();
        $data['ruangan'] = $this->Jadwal_model->get_ruangan();

        $this->load->view('admin/jadwal', $data);
    }

    // Tambah jadwal baru
    public function tambah()
    {
        $data = [
            'nama_kelas' => $this->input->post('nama_kelas'),
            'id_mata_kuliah' => $this->input->post('id_mata_kuliah'),
            'id_ruangan' => $this->input->post('id_ruangan'),
            'nidn' => $this->input->post('nidn'),
            'hari' => $this->input->post('hari'),
            'jam' => $this->input->post('jam')
        ];

        $this->Jadwal_model->insert($data);
        redirect('admin/jadwal');
    }

    // Edit jadwal
    public function edit($id)
    {
        $data['jdl'] = $this->Jadwal_model->get_by_id($id);
        $data['mata_kuliah'] = $this->Jadwal_model->get_mata_kuliah();
        $data['dosen'] = $this->Jadwal_model->get_dosen();
        $data['ruangan'] = $this->Jadwal_model->get_ruangan();

        $this->load->view('admin/jadwal_edit', $data);
    }

    // Update jadwal
    public function update()
    {
        $id = $this->input->post('id');

        $data = [
            'nama_kelas' => $this->input->post('nama_kelas'),
            'id_mata_kuliah' => $this->input->post('id_mata_kuliah'),
            'id_ruangan' => $this->input->post('id_ruangan'),
            'nidn' => $this->input->post('nidn'),
            'hari' => $this->input->post('hari'),
            'jam' => $this->input->post('jam')
        ];

        $this->Jadwal_model->update($id, $data);
        redirect('admin/jadwal');
    }

    // Hapus jadwal
    public function hapus($id)
    {
        $this->Jadwal_model->delete($id);
        redirect('admin/jadwal');
    }
}
