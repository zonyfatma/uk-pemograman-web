<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('role') !== 'admin') {
            redirect('auth');
        }
        $this->load->model('Mahasiswa_model');
        $this->load->helper('url');
    }

    public function index()
    {
        $data['mahasiswa'] = $this->Mahasiswa_model->get_all();
        $this->load->view('admin/mahasiswa', $data);
    }

    public function tambah()
    {
        $nim = $this->input->post('nim');
        $nama = $this->input->post('nama');

        $data = [
            'nim' => $nim,
            'nama' => $nama
        ];

        $this->Mahasiswa_model->insert($data);
        redirect('admin/mahasiswa');
    }

    public function edit($nim)
    {
        $data['mhs'] = $this->Mahasiswa_model->get_by_id($nim);
        $this->load->view('admin/mahasiswa_edit', $data);
    }

    public function update()
    {
        $nim = $this->input->post('nim');
        $nama = $this->input->post('nama');

        $data = ['nama' => $nama];
        $this->Mahasiswa_model->update($nim, $data);
        redirect('admin/mahasiswa');
    }

    public function hapus($nim)
    {
        $this->Mahasiswa_model->delete($nim);
        redirect('admin/mahasiswa');
    }
}
