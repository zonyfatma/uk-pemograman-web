<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Mahasiswa extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->library('session');
        $user = $this->session->userdata('user');
        if(!$user || $user['role']!=='mahasiswa') redirect('auth/login');
        $this->nim = $user['ref_nim'];
        $this->load->model(['Jadwal_model','Rencana_studi_model','Nilai_mutu_model','Mata_kuliah_model']);
    }

    public function index(){
        $data['rencana'] = $this->Rencana_studi_model->get_by_nim($this->nim);
        $this->load->view('templates/header');
        $this->load->view('mahasiswa/hasil_studi',$data);
        $this->load->view('templates/footer');
    }

    public function buat_rencana(){
        if($this->input->method()==='post'){
            $id_jadwal = $this->input->post('id_jadwal');
            $this->Rencana_studi_model->insert(['nim'=>$this->nim,'id_jadwal'=>$id_jadwal]);
            redirect('mahasiswa');
        }
        $data['jadwals'] = $this->Jadwal_model->get_all();
        $this->load->view('templates/header');
        $this->load->view('mahasiswa/rencana_form',$data);
        $this->load->view('templates/footer');
    }
}
