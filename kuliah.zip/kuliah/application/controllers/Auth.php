<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Auth extends CI_Controller {
    public function __construct(){
    parent::__construct();     // ← benar
    $this->load->model('User_model');
    $this->load->library(['session', 'form_validation']);
    }


    public function login(){
        if($this->session->userdata('user')) redirect('home');
        $this->load->view('auth/login');
    }

    public function doLogin(){
        $u = $this->input->post('username', true);
        $p = $this->input->post('password', true);
        $user = $this->User_model->get_by_username($u);
        if($user && password_verify($p, $user->password)){
            $sess = [
              'id_user'=>$user->id_user,
              'username'=>$user->username,
              'nama_user'=>$user->nama_user,
              'role'=>$user->role,
              'ref_nim'=>$user->ref_nim,
              'ref_nidn'=>$user->ref_nidn
            ];
            $this->session->set_userdata('user', $sess);
            redirect('home');
        } else {
            $this->session->set_flashdata('error','Username atau password salah');
            redirect('auth/login');
        }
    }

    public function logout(){
        $this->session->unset_userdata('user');
        redirect('auth/login');
    }
}
