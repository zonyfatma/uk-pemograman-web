<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->library('session');
        $user = $this->session->userdata('user');
        if(!$user || $user['role']!=='admin') redirect('auth/login');
        $this->load->model(['Mahasiswa_model','DosenModel','Ruangan_model','Jadwal_model','Mata_kuliah_model','User_model']);
    }

    public function index(){
        $this->load->view('templates/header');
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }

    /* Mahasiswa CRUD */
    public function mahasiswa(){
        $data['mahasiswa'] = $this->Mahasiswa_model->get_all();
        $this->load->view('templates/header');
        $this->load->view('admin/mahasiswa_list',$data);
        $this->load->view('templates/footer');
    }

    public function mahasiswa_add(){
        if($this->input->method()==='post'){
            $this->Mahasiswa_model->insert([
                'nim'=>$this->input->post('nim'),
                'nama'=>$this->input->post('nama')
            ]);
            redirect('admin/mahasiswa');
        }
        $this->load->view('templates/header');
        $this->load->view('admin/mahasiswa_form');
        $this->load->view('templates/footer');
    }

    public function mahasiswa_edit($nim){
        if($this->input->method()==='post'){
            $this->Mahasiswa_model->update($nim, [
                'nama'=>$this->input->post('nama')
            ]);
            redirect('admin/mahasiswa');
        }
        $data['mhs'] = $this->Mahasiswa_model->get($nim);
        $this->load->view('templates/header');
        $this->load->view('admin/mahasiswa_form',$data);
        $this->load->view('templates/footer');
    }

    public function mahasiswa_delete($nim){
        $this->Mahasiswa_model->delete($nim);
        redirect('admin/mahasiswa');
    }

    /* Dosen CRUD */
    public function dosen(){
        $data['dosen'] = $this->DosenModel->get_all();
        $this->load->view('templates/header');
        $this->load->view('admin/dosen_list',$data);
        $this->load->view('templates/footer');
    }

    public function dosen_add(){
        if($this->input->method()==='post'){
            $this->DosenModel->insert([
                'nidn'=>$this->input->post('nidn'),
                'nama'=>$this->input->post('nama')
            ]);
            redirect('admin/dosen');
        }
        $this->load->view('templates/header');
        $this->load->view('admin/dosen_form');
        $this->load->view('templates/footer');
    }

    public function dosen_edit($nidn){
        if($this->input->method()==='post'){
            $this->db->where('nidn', $nidn);
            $this->db->update('dosen', [
                'nama'=>$this->input->post('nama')
            ]);
            redirect('admin/dosen');
        }
        $data['dsn'] = $this->db->get_where('dosen',['nidn'=>$nidn])->row();
        $this->load->view('templates/header');
        $this->load->view('admin/dosen_form',$data);
        $this->load->view('templates/footer');
    }

    public function dosen_delete($nidn){
        $this->DosenModel->delete($nidn);
        redirect('admin/dosen');
    }

    /* Ruangan CRUD */
    public function ruangan(){
        $data['ruangan'] = $this->Ruangan_model->get_all();
        $this->load->view('templates/header');
        $this->load->view('admin/ruangan_list',$data);
        $this->load->view('templates/footer');
    }
    public function ruangan_add(){
        if($this->input->method()==='post'){
            $this->Ruangan_model->insert(['nama_ruangan'=>$this->input->post('nama_ruangan')]);
            redirect('admin/ruangan');
        }
        $this->load->view('templates/header');
        $this->load->view('admin/ruangan_form');
        $this->load->view('templates/footer');
    }
    public function ruangan_edit($id){
        if($this->input->method()==='post'){
            $this->Ruangan_model->update($id, [
                'nama_ruangan'=>$this->input->post('nama_ruangan')
            ]);
            redirect('admin/ruangan');
        }
        $data['rng'] = $this->Ruangan_model->get_by_id($id);
        $this->load->view('templates/header');
        $this->load->view('admin/ruangan_form', $data);
        $this->load->view('templates/footer');
    }
    public function ruangan_delete($id){
        $this->Ruangan_model->delete($id);
        redirect('admin/ruangan');
    }

    /* Jadwal CRUD */
    public function jadwal(){
        $data['jadwal'] = $this->Jadwal_model->get_all();
        $data['mata_kuliah'] = $this->Mata_kuliah_model->get_all();
        $data['ruangan'] = $this->Ruangan_model->get_all();
        $data['dosen'] = $this->DosenModel->get_all();
        $this->load->view('templates/header');
        $this->load->view('admin/jadwal_list',$data);
        $this->load->view('templates/footer');
    }

    public function jadwal_add(){
        if($this->input->method()==='post'){
            $this->Jadwal_model->insert([
                'nama_kelas'=>$this->input->post('nama_kelas'),
                'id_mata_kuliah'=>$this->input->post('id_mata_kuliah'),
                'id_ruangan'=>$this->input->post('id_ruangan'),
                'nidn'=>$this->input->post('nidn'),
                'hari'=>$this->input->post('hari'),
                'jam'=>$this->input->post('jam')
            ]);
            redirect('admin/jadwal');
        }
        $data['mata_kuliah'] = $this->Mata_kuliah_model->get_all();
        $data['ruangan'] = $this->Ruangan_model->get_all();
        $data['dosen'] = $this->DosenModel->get_all();
        $this->load->view('templates/header');
        $this->load->view('admin/jadwal_form',$data);
        $this->load->view('templates/footer');
    }

    public function jadwal_edit($id){
        if($this->input->method()==='post'){
            $this->Jadwal_model->update($id, [
                'nama_kelas'=>$this->input->post('nama_kelas'),
                'id_mata_kuliah'=>$this->input->post('id_mata_kuliah'),
                'id_ruangan'=>$this->input->post('id_ruangan'),
                'nidn'=>$this->input->post('nidn'),
                'hari'=>$this->input->post('hari'),
                'jam'=>$this->input->post('jam')
            ]);
            redirect('admin/jadwal');
        }
        $data['jadwal'] = $this->Jadwal_model->get($id);
        $data['mata_kuliah'] = $this->Mata_kuliah_model->get_all();
        $data['ruangan'] = $this->Ruangan_model->get_all();
        $data['dosen'] = $this->DosenModel->get_all();
        $this->load->view('templates/header');
        $this->load->view('admin/jadwal_form',$data);
        $this->load->view('templates/footer');
    }

    public function jadwal_delete($id){
        $this->Jadwal_model->delete($id);
        redirect('admin/jadwal');
    }
}
