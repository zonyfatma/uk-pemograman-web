<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nilai extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('role') !== 'dosen') {
            redirect('auth');
        }
        $this->load->model('Nilai_model');
        $this->load->helper('url');
    }

    // Halaman utama: daftar jadwal yang diampu dosen
    public function index()
    {
        $nidn = $this->session->userdata('nidn');
        $data['jadwal'] = $this->Nilai_model->get_jadwal_by_dosen($nidn);
        $this->load->view('dosen/nilai', $data);
    }

    // Menampilkan mahasiswa di kelas/jadwal tertentu
    public function kelas($id_jadwal)
    {
        $data['mahasiswa'] = $this->Nilai_model->get_mahasiswa_by_jadwal($id_jadwal);
        $data['id_jadwal'] = $id_jadwal;
        $this->load->view('dosen/nilai', $data);
    }

    // Simpan nilai
    public function simpan()
    {
        $id_rencana_studi = $this->input->post('id_rencana_studi');
        $nilai_angka = $this->input->post('nilai_angka');
        $nilai_huruf = $this->input->post('nilai_huruf');

        for ($i = 0; $i < count($id_rencana_studi); $i++) {
            $this->Nilai_model->update_nilai($id_rencana_studi[$i], $nilai_angka[$i], $nilai_huruf[$i]);
        }

        redirect('dosen/nilai');
    }
}
