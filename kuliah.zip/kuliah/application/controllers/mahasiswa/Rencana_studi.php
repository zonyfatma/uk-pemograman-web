<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rencana_studi extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('role') !== 'mahasiswa') {
            redirect('auth');
        }
        $this->load->model('Rencana_studi_model');
        $this->load->helper('url');
    }

    public function index()
    {
        $nim = $this->session->userdata('nim');
        $data['jadwal'] = $this->Rencana_studi_model->get_jadwal();
        $data['rencana'] = $this->Rencana_studi_model->get_rencana_by_nim($nim);

        $this->load->view('mahasiswa/rencana_studi', $data);
    }

    public function ambil($id_jadwal)
    {
        $nim = $this->session->userdata('nim');
        $data = [
            'nim' => $nim,
            'id_jadwal' => $id_jadwal
        ];
        $this->Rencana_studi_model->insert($data);
        redirect('mahasiswa/rencana_studi');
    }

    public function hapus($id_rencana_studi)
    {
        $this->Rencana_studi_model->delete($id_rencana_studi);
        redirect('mahasiswa/rencana_studi');
    }
}
