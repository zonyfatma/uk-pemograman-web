<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('role') !== 'mahasiswa') {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['nama'] = $this->session->userdata('nama_user');
        $this->load->view('mahasiswa/dashboard', $data);
    }
}
