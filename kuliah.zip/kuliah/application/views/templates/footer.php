<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</div>
<hr/>
<footer style="text-align:center">© 2025 Kuliah</footer>
</body>
</html>
