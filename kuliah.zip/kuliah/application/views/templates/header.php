<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($title) ? $title . ' | Sistem Akademik' : 'Sistem Akademik'; ?></title>
  <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>
  <header class="navbar">
    <div class="logo">
      🎓 <span>Sistem Akademik</span>
    </div>

    <nav class="nav-links">
      <a href="<?= site_url('admin'); ?>" class="<?= current_url() == site_url('admin') ? 'active' : ''; ?>">Dashboard</a>
      <a href="<?= site_url('admin/mahasiswa'); ?>" class="<?= current_url() == site_url('admin/mahasiswa') ? 'active' : ''; ?>">Mahasiswa</a>
      <a href="<?= site_url('admin/dosen'); ?>" class="<?= current_url() == site_url('admin/dosen') ? 'active' : ''; ?>">Dosen</a>
      <a href="<?= site_url('admin/ruangan'); ?>" class="<?= current_url() == site_url('admin/ruangan') ? 'active' : ''; ?>">Ruangan</a>
      <a href="<?= site_url('admin/jadwal'); ?>" class="<?= current_url() == site_url('admin/jadwal') ? 'active' : ''; ?>">Jadwal</a>
      <a href="<?= site_url('auth/logout'); ?>" class="logout">Logout</a>
    </nav>
  </header>

  <main class="container">
