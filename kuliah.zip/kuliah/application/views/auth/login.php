<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Sistem Perkuliahan</title>

    <!-- Load CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css?v=4') ?>">
</head>

<body class="login-page">

    <div class="login-container">
        <div class="login-box">

            <h2 class="login-title">Login Sistem Perkuliahan</h2>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert">
                    <?= $this->session->flashdata('error'); ?>
                </div>
            <?php endif; ?>

            <form action="<?= site_url('auth/doLogin') ?>" method="post">

                <div class="form-group">
                    <label for="username">Username</label>
                    <input 
                        type="text" 
                        name="username" 
                        id="username" 
                        placeholder="Masukkan username" 
                        required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input 
                        type="password" 
                        name="password" 
                        id="password" 
                        placeholder="Masukkan password" 
                        required>
                </div>

                <button type="submit" class="btn-login">Masuk</button>

            </form>

            <p class="login-note">Login sebagai Admin, Dosen, atau Mahasiswa</p>

        </div>
    </div>

    <div class="footer">
        &copy; <?= date('Y') ?> Sistem Akademik | CodeIgniter 3
    </div>

</body>
</html>
