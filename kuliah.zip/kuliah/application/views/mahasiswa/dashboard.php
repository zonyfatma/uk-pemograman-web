<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Mahasiswa</title>
</head>
<body>
    <h2>Halo, <?= $nama; ?> 🎓</h2>
    <h3>Selamat datang di Dashboard Mahasiswa</h3>

    <ul>
        <li><a href="<?= site_url('mahasiswa/rencana_studi'); ?>">Rencana Studi (KRS)</a></li>
        <li><a href="<?= site_url('mahasiswa/hasil_studi'); ?>">Hasil Studi (IPK)</a></li>
    </ul>

    <a href="<?= site_url('auth/logout'); ?>">Logout</a>
</body>
</html>
