<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h3>Buat Rencana Studi</h3>
<form method="post" action="<?= site_url('mahasiswa/buat_rencana') ?>">
  <label>Pilih Jadwal</label><br/>
  <select name="id_jadwal">
    <?php foreach($jadwals as $j): ?>
      <option value="<?= $j->id ?>"><?= $j->nama_kelas ?> - <?= $j->nama_mata_kuliah ?> (<?= $j->sks ?> SKS) - <?= $j->nama_dosen ?> - <?= $j->hari ?> <?= $j->jam ?></option>
    <?php endforeach; ?>
  </select><br/><br/>
  <button type="submit">Ambil Mata Kuliah</button>
</form>
