<!DOCTYPE html>
<html>
<head>
    <title>Rencana Studi (KRS)</title>
</head>
<body>
    <h2>Rencana Studi Mahasiswa</h2>

    <h3>Pilih Mata Kuliah (KRS)</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>Mata Kuliah</th>
            <th>Dosen</th>
            <th>Ruangan</th>
            <th>Hari</th>
            <th>Jam</th>
            <th>Aksi</th>
        </tr>
        <?php foreach ($jadwal as $j): ?>
        <tr>
            <td><?= $j->nama_mata_kuliah; ?></td>
            <td><?= $j->nama_dosen; ?></td>
            <td><?= $j->nama_ruangan; ?></td>
            <td><?= $j->hari; ?></td>
            <td><?= $j->jam; ?></td>
            <td><a href="<?= site_url('mahasiswa/rencana_studi/ambil/'.$j->id); ?>">Ambil</a></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <hr>

    <h3>Mata Kuliah yang Diambil</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>Mata Kuliah</th>
            <th>Dosen</th>
            <th>Hari</th>
            <th>Jam</th>
            <th>Aksi</th>
        </tr>
        <?php foreach ($rencana as $r): ?>
        <tr>
            <td><?= $r->nama_mata_kuliah; ?></td>
            <td><?= $r->nama_dosen; ?></td>
            <td><?= $r->hari; ?></td>
            <td><?= $r->jam; ?></td>
            <td><a href="<?= site_url('mahasiswa/rencana_studi/hapus/'.$r->id_rencana_studi); ?>">Hapus</a></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <a href="<?= site_url('mahasiswa/dashboard'); ?>">← Kembali ke Dashboard</a>
</body>
</html>
