<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h3>Hasil Studi</h3>
<a href="<?= site_url('mahasiswa/buat_rencana') ?>">Tambah Rencana Studi</a>
<table>
<tr><th>Mata Kuliah</th><th>SKS</th><th>Nilai Angka</th><th>Nilai Huruf</th><th>Nilai Mutu</th></tr>
<?php
$total_sks = 0;
$total_nilai_mutu = 0;
$this->load->model('Nilai_mutu_model');
foreach($rencana as $r):
  $sks = $r->sks;
  $nilai_mutu = 0;
  if($r->nilai_huruf){
    $nm = $this->Nilai_mutu_model->get($r->nilai_huruf);
    $nilai_mutu = $nm ? $nm->nilai_mutu : 0;
  }
  $total_sks += $sks;
  $total_nilai_mutu += ($nilai_mutu * $sks);
?>
<tr>
  <td><?= $r->nama_mata_kuliah ?></td>
  <td><?= $sks ?></td>
  <td><?= $r->nilai_angka ?></td>
  <td><?= $r->nilai_huruf ?></td>
  <td><?= $nilai_mutu ?></td>
</tr>
<?php endforeach; ?>
</table>
<?php $ipk = $total_sks>0 ? round($total_nilai_mutu/$total_sks,2) : 0; ?>
<p>Total SKS: <?= $total_sks ?></p>
<p>IPK: <?= $ipk ?></p>
