<!DOCTYPE html>
<html>
<head>
    <title>Edit Ruangan</title>
</head>
<body>
    <h2>Edit Data Ruangan</h2>

    <form method="POST" action="<?= site_url('admin/ruangan/update'); ?>">
        <input type="hidden" name="id_ruangan" value="<?= $rgn->id_ruangan; ?>">
        <label>Nama Ruangan:</label>
        <input type="text" name="nama_ruangan" value="<?= $rgn->nama_ruangan; ?>" required>
        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?= site_url('admin/ruangan'); ?>">← Kembali</a>
</body>
</html>
