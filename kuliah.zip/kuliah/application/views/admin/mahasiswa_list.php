<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h3>Daftar Mahasiswa</h3>
<a href="<?= site_url('admin/mahasiswa_add') ?>">Tambah Mahasiswa</a>
<table>
<tr><th>NIM</th><th>Nama</th><th>Aksi</th></tr>
<?php foreach($mahasiswa as $m): ?>
<tr>
  <td><?= $m->nim ?></td>
  <td><?= $m->nama ?></td>
  <td>
    <a href="<?= site_url('admin/mahasiswa_edit/'.$m->nim) ?>">Edit</a> |
    <a href="<?= site_url('admin/mahasiswa_delete/'.$m->nim) ?>" onclick="return confirm('Hapus?')">Hapus</a>
  </td>
</tr>
<?php endforeach; ?>
</table>
