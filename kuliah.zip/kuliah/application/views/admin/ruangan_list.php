<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h3>Daftar Ruangan</h3>
<a href="<?= site_url('admin/ruangan_add') ?>">Tambah Ruangan</a>
<table>
<tr><th>ID</th><th>Nama Ruangan</th><th>Aksi</th></tr>
<?php foreach($ruangan as $r): ?>
<tr>
  <td><?= $r->id_ruangan ?></td>
  <td><?= $r->nama_ruangan ?></td>
  <td>
    <a href="<?= site_url('admin/ruangan_edit/'.$r->id_ruangan) ?>">Edit</a> |
    <a href="<?= site_url('admin/ruangan_delete/'.$r->id_ruangan) ?>" onclick="return confirm('Hapus?')">Hapus</a>
  </td>
</tr>
<?php endforeach; ?>
</table>
