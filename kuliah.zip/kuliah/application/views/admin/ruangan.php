<!DOCTYPE html>
<html>
<head>
    <title>Data Ruangan</title>
</head>
<body>
    <h2>Data Ruangan</h2>

    <!-- Form Tambah -->
    <h3>Tambah Ruangan Baru</h3>
    <form method="POST" action="<?= site_url('admin/ruangan/tambah'); ?>">
        <label>Nama Ruangan:</label>
        <input type="text" name="nama_ruangan" required>
        <button type="submit">Tambah</button>
    </form>

    <hr>

    <!-- Tabel Data -->
    <h3>Daftar Ruangan</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>ID Ruangan</th>
            <th>Nama Ruangan</th>
            <th>Aksi</th>
        </tr>

        <?php foreach ($ruangan as $r): ?>
        <tr>
            <td><?= $r->id_ruangan; ?></td>
            <td><?= $r->nama_ruangan; ?></td>
            <td>
                <a href="<?= site_url('admin/ruangan/edit/'.$r->id_ruangan); ?>">Edit</a> |
                <a href="<?= site_url('admin/ruangan/hapus/'.$r->id_ruangan); ?>" onclick="return confirm('Yakin ingin hapus?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <a href="<?= site_url('admin/dashboard'); ?>">← Kembali ke Dashboard</a>
</body>
</html>
