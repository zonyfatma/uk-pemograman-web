<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h2>Dashboard Admin</h2>
<ul>
  <li><a href="<?= site_url('admin/mahasiswa') ?>">Mahasiswa</a></li>
  <li><a href="<?= site_url('admin/dosen') ?>">Dosen</a></li>
  <li><a href="<?= site_url('admin/ruangan') ?>">Ruangan</a></li>
  <li><a href="<?= site_url('admin/jadwal') ?>">Jadwal</a></li>
</ul>
