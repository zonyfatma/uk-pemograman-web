<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">

<h3><?= isset($dsn) ? 'Edit Dosen' : 'Tambah Dosen' ?></h3>

<form method="post" action="">
  <label>NIDN:</label><br>
  <input type="text" name="nidn" value="<?= isset($dsn) ? $dsn->nidn : '' ?>" <?= isset($dsn) ? 'readonly' : '' ?> required><br><br>

  <label>Nama:</label><br>
  <input type="text" name="nama" value="<?= isset($dsn) ? $dsn->nama : '' ?>" required><br><br>

  <button type="submit"><?= isset($dsn) ? 'Update' : 'Simpan' ?></button>
</form>
