<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h3>Daftar Dosen</h3>
<a href="<?= site_url('admin/dosen_add') ?>">Tambah Dosen</a>
<table>
<tr><th>NIDN</th><th>Nama</th><th>Aksi</th></tr>
<?php foreach($dosen as $d): ?>
<tr>
  <td><?= $d->nidn ?></td>
  <td><?= $d->nama ?></td>
  <td>
    <a href="<?= site_url('admin/dosen_edit/'.$d->nidn) ?>">Edit</a> |
    <a href="<?= site_url('admin/dosen_delete/'.$d->nidn) ?>" onclick="return confirm('Hapus?')">Hapus</a>
  </td>
</tr>
<?php endforeach; ?>
</table>
