<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">

<h3><?= isset($mhs) ? 'Edit Mahasiswa' : 'Tambah Mahasiswa' ?></h3>

<form method="post" action="">
  <label>NIM:</label><br>
  <input type="text" name="nim" value="<?= isset($mhs) ? $mhs->nim : '' ?>" <?= isset($mhs) ? 'readonly' : '' ?> required><br><br>

  <label>Nama:</label><br>
  <input type="text" name="nama" value="<?= isset($mhs) ? $mhs->nama : '' ?>" required><br><br>

  <button type="submit"><?= isset($mhs) ? 'Update' : 'Simpan' ?></button>
</form>
