<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">

<h3><?= isset($jadwal) ? 'Edit Jadwal' : 'Tambah Jadwal' ?></h3>

<form method="post" action="">
  <label>Nama Kelas:</label><br>
  <input type="text" name="nama_kelas" value="<?= isset($jadwal) ? $jadwal->nama_kelas : '' ?>" required><br><br>

  <label>Mata Kuliah:</label><br>
  <select name="id_mata_kuliah" required>
    <option value="">--Pilih--</option>
    <?php foreach($mata_kuliah as $mk): ?>
      <option value="<?= $mk->id_mata_kuliah ?>" <?= isset($jadwal) && $jadwal->id_mata_kuliah == $mk->id_mata_kuliah ? 'selected' : '' ?>>
        <?= $mk->nama_mata_kuliah ?>
      </option>
    <?php endforeach; ?>
  </select><br><br>

  <label>Ruangan:</label><br>
  <select name="id_ruangan" required>
    <option value="">--Pilih--</option>
    <?php foreach($ruangan as $r): ?>
      <option value="<?= $r->id_ruangan ?>" <?= isset($jadwal) && $jadwal->id_ruangan == $r->id_ruangan ? 'selected' : '' ?>>
        <?= $r->nama_ruangan ?>
      </option>
    <?php endforeach; ?>
  </select><br><br>

  <label>Dosen:</label><br>
  <select name="nidn" required>
    <option value="">--Pilih--</option>
    <?php foreach($dosen as $d): ?>
      <option value="<?= $d->nidn ?>" <?= isset($jadwal) && $jadwal->nidn == $d->nidn ? 'selected' : '' ?>>
        <?= $d->nama ?>
      </option>
    <?php endforeach; ?>
  </select><br><br>

  <label>Hari:</label><br>
  <input type="text" name="hari" value="<?= isset($jadwal) ? $jadwal->hari : '' ?>" required><br><br>

  <label>Jam:</label><br>
  <input type="text" name="jam" value="<?= isset($jadwal) ? $jadwal->jam : '' ?>" required><br><br>

  <button type="submit"><?= isset($jadwal) ? 'Update' : 'Simpan' ?></button>
</form>
