<!DOCTYPE html>
<html>
<head>
    <title>Data Jadwal Kuliah</title>
</head>
<body>
    <h2>Kelola Jadwal Kuliah</h2>

    <!-- Form Tambah Jadwal -->
    <h3>Tambah Jadwal Baru</h3>
    <form method="POST" action="<?= site_url('admin/jadwal/tambah'); ?>">
        <label>Nama Kelas:</label>
        <input type="text" name="nama_kelas" required><br><br>

        <label>Mata Kuliah:</label>
        <select name="id_mata_kuliah" required>
            <option value="">-- Pilih Mata Kuliah --</option>
            <?php foreach ($mata_kuliah as $mk): ?>
                <option value="<?= $mk->id_mata_kuliah; ?>"><?= $mk->nama_mata_kuliah; ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Dosen:</label>
        <select name="nidn" required>
            <option value="">-- Pilih Dosen --</option>
            <?php foreach ($dosen as $d): ?>
                <option value="<?= $d->nidn; ?>"><?= $d->nama; ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Ruangan:</label>
        <select name="id_ruangan" required>
            <option value="">-- Pilih Ruangan --</option>
            <?php foreach ($ruangan as $r): ?>
                <option value="<?= $r->id_ruangan; ?>"><?= $r->nama_ruangan; ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Hari:</label>
        <input type="text" name="hari" required><br><br>

        <label>Jam:</label>
        <input type="text" name="jam" placeholder="Contoh: 08.00 - 10.00" required><br><br>

        <button type="submit">Tambah</button>
    </form>

    <hr>

    <!-- Tabel Jadwal -->
    <h3>Daftar Jadwal Kuliah</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th>
            <th>Kelas</th>
            <th>Mata Kuliah</th>
            <th>Dosen</th>
            <th>Ruangan</th>
            <th>Hari</th>
            <th>Jam</th>
            <th>Aksi</th>
        </tr>

        <?php foreach ($jadwal as $j): ?>
        <tr>
            <td><?= $j->id; ?></td>
            <td><?= $j->nama_kelas; ?></td>
            <td><?= $j->nama_mata_kuliah; ?></td>
            <td><?= $j->nama_dosen; ?></td>
            <td><?= $j->nama_ruangan; ?></td>
            <td><?= $j->hari; ?></td>
            <td><?= $j->jam; ?></td>
            <td>
                <a href="<?= site_url('admin/jadwal/edit/'.$j->id); ?>">Edit</a> |
                <a href="<?= site_url('admin/jadwal/hapus/'.$j->id); ?>" onclick="return confirm('Yakin ingin hapus?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <a href="<?= site_url('admin/dashboard'); ?>">← Kembali ke Dashboard</a>
</body>
</html>
