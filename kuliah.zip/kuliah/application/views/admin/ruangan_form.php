<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">

<h3><?= isset($rng) ? 'Edit Ruangan' : 'Tambah Ruangan' ?></h3>

<form method="post" action="">
  <label>Nama Ruangan:</label><br>
  <input type="text" name="nama_ruangan" value="<?= isset($rng) ? $rng->nama_ruangan : '' ?>" required><br><br>

  <button type="submit"><?= isset($rng) ? 'Update' : 'Simpan' ?></button>
</form>
