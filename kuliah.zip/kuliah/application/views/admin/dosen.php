<!DOCTYPE html>
<html>
<head>
    <title>Data Dosen</title>
</head>
<body>
    <h2>Data Dosen</h2>

    <!-- Form Tambah -->
    <h3>Tambah Dosen Baru</h3>
    <form method="POST" action="<?= site_url('admin/dosen/tambah'); ?>">
        <label>NIDN:</label>
        <input type="text" name="nidn" required>
        <label>Nama:</label>
        <input type="text" name="nama" required>
        <button type="submit">Tambah</button>
    </form>

    <hr>

    <!-- Tabel Data -->
    <h3>Daftar Dosen</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>NIDN</th>
            <th>Nama</th>
            <th>Aksi</th>
        </tr>

        <?php foreach ($dosen as $d): ?>
        <tr>
            <td><?= $d->nidn; ?></td>
            <td><?= $d->nama; ?></td>
            <td>
                <a href="<?= site_url('admin/dosen/edit/'.$d->nidn); ?>">Edit</a> |
                <a href="<?= site_url('admin/dosen/hapus/'.$d->nidn); ?>" onclick="return confirm('Yakin ingin hapus?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <a href="<?= site_url('admin/dashboard'); ?>">← Kembali ke Dashboard</a>
</body>
</html>
