<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h3>Daftar Jadwal</h3>
<a href="<?= site_url('admin/jadwal_add') ?>">Tambah Jadwal</a>
<table>
<tr><th>ID</th><th>Kelas</th><th>Mata Kuliah</th><th>SKS</th><th>Ruangan</th><th>Dosen</th><th>Hari</th><th>Jam</th><th>Aksi</th></tr>
<?php foreach($jadwal as $j): ?>
<tr>
  <td><?= $j->id ?></td>
  <td><?= $j->nama_kelas ?></td>
  <td><?= $j->nama_mata_kuliah ?></td>
  <td><?= $j->sks ?></td>
  <td><?= $j->nama_ruangan ?></td>
  <td><?= $j->nama_dosen ?></td>
  <td><?= $j->hari ?></td>
  <td><?= $j->jam ?></td>
  <td>
    <a href="<?= site_url('admin/jadwal_edit/'.$j->id) ?>">Edit</a> |
    <a href="<?= site_url('admin/jadwal_delete/'.$j->id) ?>" onclick="return confirm('Hapus?')">Hapus</a>
  </td>
</tr>
<?php endforeach; ?>
</table>
