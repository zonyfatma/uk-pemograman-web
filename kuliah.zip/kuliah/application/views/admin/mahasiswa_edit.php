<!DOCTYPE html>
<html>
<head>
    <title>Edit Mahasiswa</title>
</head>
<body>
    <h2>Edit Data Mahasiswa</h2>

    <form method="POST" action="<?= site_url('admin/mahasiswa/update'); ?>">
        <input type="hidden" name="nim" value="<?= $mhs->nim; ?>">
        <label>Nama:</label>
        <input type="text" name="nama" value="<?= $mhs->nama; ?>" required>
        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?= site_url('admin/mahasiswa'); ?>">← Kembali</a>
</body>
</html>
