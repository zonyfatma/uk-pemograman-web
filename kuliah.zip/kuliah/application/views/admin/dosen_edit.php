<!DOCTYPE html>
<html>
<head>
    <title>Edit Dosen</title>
</head>
<body>
    <h2>Edit Data Dosen</h2>

    <form method="POST" action="<?= site_url('admin/dosen/update'); ?>">
        <input type="hidden" name="nidn" value="<?= $dsn->nidn; ?>">
        <label>Nama:</label>
        <input type="text" name="nama" value="<?= $dsn->nama; ?>" required>
        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?= site_url('admin/dosen'); ?>">← Kembali</a>
</body>
</html>
