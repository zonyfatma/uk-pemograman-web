<!DOCTYPE html>
<html>
<head>
    <title>Edit Jadwal</title>
</head>
<body>
    <h2>Edit Jadwal Kuliah</h2>

    <form method="POST" action="<?= site_url('admin/jadwal/update'); ?>">
        <input type="hidden" name="id" value="<?= $jdl->id; ?>">

        <label>Nama Kelas:</label>
        <input type="text" name="nama_kelas" value="<?= $jdl->nama_kelas; ?>" required><br><br>

        <label>Mata Kuliah:</label>
        <select name="id_mata_kuliah" required>
            <?php foreach ($mata_kuliah as $mk): ?>
                <option value="<?= $mk->id_mata_kuliah; ?>" <?= $mk->id_mata_kuliah == $jdl->id_mata_kuliah ? 'selected' : ''; ?>>
                    <?= $mk->nama_mata_kuliah; ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Dosen:</label>
        <select name="nidn" required>
            <?php foreach ($dosen as $d): ?>
                <option value="<?= $d->nidn; ?>" <?= $d->nidn == $jdl->nidn ? 'selected' : ''; ?>>
                    <?= $d->nama; ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Ruangan:</label>
        <select name="id_ruangan" required>
            <?php foreach ($ruangan as $r): ?>
                <option value="<?= $r->id_ruangan; ?>" <?= $r->id_ruangan == $jdl->id_ruangan ? 'selected' : ''; ?>>
                    <?= $r->nama_ruangan; ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Hari:</label>
        <input type="text" name="hari" value="<?= $jdl->hari; ?>" required><br><br>

        <label>Jam:</label>
        <input type="text" name="jam" value="<?= $jdl->jam; ?>" required><br><br>

        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?= site_url('admin/jadwal'); ?>">← Kembali</a>
</body>
</html>
