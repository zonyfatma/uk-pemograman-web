<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
</head>
<body>
    <h2>Data Mahasiswa</h2>

    <!-- Form Tambah Mahasiswa -->
    <h3>Tambah Mahasiswa Baru</h3>
    <form method="POST" action="<?= site_url('admin/mahasiswa/tambah'); ?>">
        <label>NIM:</label>
        <input type="text" name="nim" required>
        <label>Nama:</label>
        <input type="text" name="nama" required>
        <button type="submit">Tambah</button>
    </form>

    <hr>

    <!-- Tabel Data Mahasiswa -->
    <h3>Daftar Mahasiswa</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>NIM</th>
            <th>Nama</th>
            <th>Aksi</th>
        </tr>

        <?php foreach ($mahasiswa as $m): ?>
        <tr>
            <td><?= $m->nim; ?></td>
            <td><?= $m->nama; ?></td>
            <td>
                <a href="<?= site_url('admin/mahasiswa/edit/'.$m->nim); ?>">Edit</a> |
                <a href="<?= site_url('admin/mahasiswa/hapus/'.$m->nim); ?>" onclick="return confirm('Yakin ingin hapus?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <a href="<?= site_url('admin/dashboard'); ?>">← Kembali ke Dashboard</a>
</body>
</html>
