<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h3>Isi Nilai Mahasiswa</h3>
<table>
<tr><th>NIM</th><th>Nama</th><th>Nilai Angka</th><th>Aksi</th></tr>
<?php foreach($mahasiswas as $m): ?>
<tr>
  <form method="post" action="<?= site_url('dosen/isi_nilai/'.$this->uri->segment(3)) ?>">
    <td><?= $m->nim ?></td>
    <td><?= $m->nama_mahasiswa ?></td>
    <td><input type="number" name="nilai_angka" min="0" max="100" step="0.01" value="<?= $m->nilai_angka ?>"/></td>
    <td>
      <input type="hidden" name="id_rencana_studi" value="<?= $m->id_rencana_studi ?>" />
      <button type="submit">Simpan</button>
    </td>
  </form>
</tr>
<?php endforeach; ?>
</table>
