<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<h3>Jadwal Mengajar</h3>
<table>
<tr><th>ID</th><th>Kelas</th><th>Mata Kuliah</th><th>SKS</th><th>Ruangan</th><th>Hari</th><th>Jam</th><th>Aksi</th></tr>
<?php foreach($jadwals as $j): if($j->nidn!=$this->session->userdata('user')['ref_nidn']) continue; ?>
<tr>
  <td><?= $j->id ?></td>
  <td><?= $j->nama_kelas ?></td>
  <td><?= $j->nama_mata_kuliah ?></td>
  <td><?= $j->sks ?></td>
  <td><?= $j->nama_ruangan ?></td>
  <td><?= $j->hari ?></td>
  <td><?= $j->jam ?></td>
  <td><a href="<?= site_url('dosen/isi_nilai/'.$j->id) ?>">Isi Nilai</a></td>
</tr>
<?php endforeach; ?>
</table>
