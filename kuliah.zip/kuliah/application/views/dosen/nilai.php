<div class="card">
  <h2>Input Nilai Mahasiswa</h2>

  <form method="post" action="<?= site_url('dosen/simpanNilai'); ?>">
    <input type="hidden" name="id_jadwal" value="<?= $id_jadwal; ?>">

    <table class="table">
      <thead>
        <tr>
          <th>No</th>
          <th>NIM</th>
          <th>Nama</th>
          <th>Nilai Angka</th>
          <th>Nilai Huruf</th>
        </tr>
      </thead>
      <tbody>
        <?php $no=1; foreach($mahasiswa as $m): ?>
        <tr>
          <td><?= $no++; ?></td>
          <td><?= $m->nim; ?></td>
          <td><?= $m->nama; ?></td>
          <td>
            <input type="number" step="0.01" name="nilai[<?= $m->id_rencana_studi; ?>][angka]" 
                   value="<?= $m->nilai_angka; ?>" required>
          </td>
          <td>
            <select name="nilai[<?= $m->id_rencana_studi; ?>][huruf]" required>
              <option value="">-- Pilih Huruf --</option>
              <?php foreach($nilai_huruf as $n): ?>
                <option value="<?= $n->nilai_huruf; ?>" <?= ($m->nilai_huruf == $n->nilai_huruf) ? 'selected' : ''; ?>>
                  <?= $n->nilai_huruf; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <button type="submit" class="btn">Simpan Nilai</button>
  </form>
</div>
