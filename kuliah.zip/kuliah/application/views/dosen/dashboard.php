<div class="card">
  <h2>Jadwal Mengajar Dosen</h2>
  <table class="table">
    <thead>
      <tr>
        <th>No</th>
        <th>Mata Kuliah</th>
        <th>Ruangan</th>
        <th>Hari</th>
        <th>Jam</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $no=1; foreach($jadwal as $j): ?>
      <tr>
        <td><?= $no++; ?></td>
        <td><?= $j->nama_mata_kuliah; ?></td>
        <td><?= $j->nama_ruangan; ?></td>
        <td><?= $j->hari; ?></td>
        <td><?= $j->jam; ?></td>
        <td><a href="<?= site_url('dosen/nilai/'.$j->id); ?>" class="btn">Isi Nilai</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
