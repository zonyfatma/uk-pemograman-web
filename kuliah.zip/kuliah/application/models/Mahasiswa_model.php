<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Mahasiswa_model extends CI_Model {
    protected $table = 'mahasiswa';
    public function __construct(){ parent::__construct(); }
    public function get_all(){ return $this->db->get($this->table)->result(); }
    public function get($nim){ return $this->db->get_where($this->table,['nim'=>$nim])->row(); }
    public function insert($data){ return $this->db->insert($this->table,$data); }
    public function update($nim,$data){ return $this->db->where('nim',$nim)->update($this->table,$data); }
    public function delete($nim){ return $this->db->delete($this->table,['nim'=>$nim]); }
    public function get_by_id($nim){ return $this->db->get_where('mahasiswa',['nim'=>$nim])->row(); }
}
