<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nilai_model extends CI_Model {

    // Ambil jadwal yang diampu oleh dosen berdasarkan NIDN
    public function get_jadwal_by_dosen($nidn)
    {
        $this->db->select('jadwal.id, mata_kuliah.nama_mata_kuliah, ruangan.nama_ruangan, jadwal.hari, jadwal.jam, jadwal.nama_kelas');
        $this->db->from('jadwal');
        $this->db->join('mata_kuliah', 'jadwal.id_mata_kuliah = mata_kuliah.id_mata_kuliah');
        $this->db->join('ruangan', 'jadwal.id_ruangan = ruangan.id_ruangan');
        $this->db->where('jadwal.nidn', $nidn);
        return $this->db->get()->result();
    }

    // Ambil daftar mahasiswa dari jadwal tertentu
    public function get_mahasiswa_by_jadwal($id_jadwal)
    {
        $this->db->select('rencana_studi.id_rencana_studi, mahasiswa.nim, mahasiswa.nama, rencana_studi.nilai_angka, rencana_studi.nilai_huruf');
        $this->db->from('rencana_studi');
        $this->db->join('mahasiswa', 'rencana_studi.nim = mahasiswa.nim');
        $this->db->where('rencana_studi.id_jadwal', $id_jadwal);
        return $this->db->get()->result();
    }

    // Update nilai mahasiswa
    public function update_nilai($id_rencana_studi, $nilai_angka, $nilai_huruf)
    {
        $data = [
            'nilai_angka' => $nilai_angka,
            'nilai_huruf' => $nilai_huruf
        ];
        $this->db->where('id_rencana_studi', $id_rencana_studi);
        return $this->db->update('rencana_studi', $data);
    }
}
