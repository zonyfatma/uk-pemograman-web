<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DosenModel extends CI_Model {

    // Ambil semua data dosen (untuk admin)
    public function get_all() {
        return $this->db->get('dosen')->result();
    }

    // Tambah data dosen baru
    public function insert($data) {
        return $this->db->insert('dosen', $data);
    }

    // Hapus data dosen berdasarkan NIDN
    public function delete($nidn) {
        $this->db->where('nidn', $nidn);
        return $this->db->delete('dosen');
    }

    public function get_by_id($nidn){
        return $this->db->get_where('dosen',['nidn'=>$nidn])->row();
    }
    public function update($nidn, $data){
        $this->db->where('nidn',$nidn)->update('dosen',$data);
    }

    // ====================== UNTUK DOSEN ======================

    // Ambil jadwal mengajar berdasarkan NIDN dosen login
    public function getJadwalByDosen($nidn) {
        $this->db->select('j.*, m.nama_mata_kuliah, r.nama_ruangan');
        $this->db->from('jadwal j');
        $this->db->join('mata_kuliah m', 'm.id_mata_kuliah = j.id_mata_kuliah');
        $this->db->join('ruangan r', 'r.id_ruangan = j.id_ruangan');
        $this->db->where('j.nidn', $nidn);
        return $this->db->get()->result();
    }

    // Ambil daftar mahasiswa berdasarkan jadwal tertentu
    public function getMahasiswaByJadwal($id_jadwal) {
        $this->db->select('r.id_rencana_studi, m.nim, m.nama, r.nilai_angka, r.nilai_huruf');
        $this->db->from('rencana_studi r');
        $this->db->join('mahasiswa m', 'm.nim = r.nim');
        $this->db->where('r.id_jadwal', $id_jadwal);
        return $this->db->get()->result();
    }

    // Update nilai mahasiswa
    public function updateNilai($id_rencana_studi, $nilai_angka, $nilai_huruf) {
        $data = [
            'nilai_angka' => $nilai_angka,
            'nilai_huruf' => $nilai_huruf
        ];
        $this->db->where('id_rencana_studi', $id_rencana_studi);
        $this->db->update('rencana_studi', $data);
    }
}
