<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen_model extends CI_Model {

    // Ambil semua data dosen
    public function get_all()
    {
        return $this->db->get('dosen')->result();
    }

    // Tambah data dosen baru
    public function insert($data)
    {
        return $this->db->insert('dosen', $data);
    }

    // Ambil data dosen berdasarkan NIDN
    public function get_by_id($nidn)
    {
        return $this->db->get_where('dosen', ['nidn' => $nidn])->row();
    }

    // Update data dosen
    public function update($nidn, $data)
    {
        $this->db->where('nidn', $nidn);
        return $this->db->update('dosen', $data);
    }

    // Hapus data dosen
    public function delete($nidn)
    {
        $this->db->where('nidn', $nidn);
        return $this->db->delete('dosen');
    }
}
