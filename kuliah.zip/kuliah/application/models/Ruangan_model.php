<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Ruangan_model extends CI_Model {
    protected $table = 'ruangan';
    public function __construct(){ parent::__construct(); }
    public function get_all(){ return $this->db->get($this->table)->result(); }
    public function get($id){ return $this->db->get_where($this->table,['id_ruangan'=>$id])->row(); }
    public function insert($data){ return $this->db->insert($this->table,$data); }
    public function update($id,$data){ return $this->db->where('id_ruangan',$id)->update($this->table,$data); }
    public function delete($id){ return $this->db->delete($this->table,['id_ruangan'=>$id]); }
    public function get_by_id($id){ return $this->db->get_where('ruangan',['id_ruangan'=>$id])->row(); }
}
