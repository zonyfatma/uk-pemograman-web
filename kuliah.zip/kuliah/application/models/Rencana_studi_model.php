<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Rencana_studi_model extends CI_Model {
    protected $table = 'rencana_studi';
    public function __construct(){ parent::__construct(); }
    public function get_by_nim($nim){
        $this->db->select('rencana_studi.*, jadwal.nama_kelas, mata_kuliah.nama_mata_kuliah, mata_kuliah.sks, dosen.nama as nama_dosen');
        $this->db->from('rencana_studi');
        $this->db->join('jadwal','jadwal.id=rencana_studi.id_jadwal');
        $this->db->join('mata_kuliah','mata_kuliah.id_mata_kuliah=jadwal.id_mata_kuliah');
        $this->db->join('dosen','dosen.nidn=jadwal.nidn');
        $this->db->where('rencana_studi.nim',$nim);
        return $this->db->get()->result();
    }
    public function insert($data){ return $this->db->insert($this->table,$data); }
    public function get_by_jadwal($id_jadwal){
        $this->db->select('rencana_studi.*, mahasiswa.nama as nama_mahasiswa');
        $this->db->from('rencana_studi');
        $this->db->join('mahasiswa','mahasiswa.nim=rencana_studi.nim');
        $this->db->where('id_jadwal',$id_jadwal);
        return $this->db->get()->result();
    }
    public function update($id,$data){ return $this->db->where('id_rencana_studi',$id)->update($this->table,$data); }
}
