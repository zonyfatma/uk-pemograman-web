<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Jadwal_model extends CI_Model {
    protected $table = 'jadwal';
    public function __construct(){ parent::__construct(); }
    public function get_all(){
        $this->db->select('jadwal.*, mata_kuliah.nama_mata_kuliah, mata_kuliah.sks, ruangan.nama_ruangan, dosen.nama as nama_dosen, jadwal.nidn');
        $this->db->from('jadwal');
        $this->db->join('mata_kuliah','mata_kuliah.id_mata_kuliah=jadwal.id_mata_kuliah');
        $this->db->join('ruangan','ruangan.id_ruangan=jadwal.id_ruangan');
        $this->db->join('dosen','dosen.nidn=jadwal.nidn');
        return $this->db->get()->result();
    }
    public function get($id){ return $this->db->get_where($this->table,['id'=>$id])->row(); }
    public function insert($data){ return $this->db->insert($this->table,$data); }
    public function update($id,$data){ return $this->db->where('id',$id)->update($this->table,$data); }
    public function delete($id){ return $this->db->delete($this->table,['id'=>$id]); }
}
