<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Nilai_mutu_model extends CI_Model {
    protected $table = 'nilai_mutu';

    public function __construct(){ 
        parent::__construct(); 
    }

    public function get($huruf){ 
        return $this->db->get_where($this->table, ['nilai_huruf' => $huruf])->row(); 
    }

    public function get_all(){
        return $this->db->get($this->table)->result(); // ambil semua nilai huruf
    }
}
