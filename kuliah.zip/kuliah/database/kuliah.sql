-- Create database
CREATE DATABASE IF NOT EXISTS kuliah;
USE kuliah;

-- Create tables
CREATE TABLE mahasiswa (
    nim VARCHAR(20) PRIMARY KEY,
    nama VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE dosen (
    nidn VARCHAR(20) PRIMARY KEY,
    nama VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE mata_kuliah (
    id_mata_kuliah INT AUTO_INCREMENT PRIMARY KEY,
    kode_mata_kuliah VARCHAR(10) NOT NULL,
    nama_mata_kuliah VARCHAR(100) NOT NULL,
    sks INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE ruangan (
    id_ruangan INT AUTO_INCREMENT PRIMARY KEY,
    nama_ruangan VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE jadwal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kelas VARCHAR(50) NOT NULL,
    id_mata_kuliah INT NOT NULL,
    id_ruangan INT NOT NULL,
    nidn VARCHAR(20) NOT NULL,
    hari VARCHAR(10) NOT NULL,
    jam VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_mata_kuliah) REFERENCES mata_kuliah(id_mata_kuliah) ON DELETE CASCADE,
    FOREIGN KEY (id_ruangan) REFERENCES ruangan(id_ruangan) ON DELETE CASCADE,
    FOREIGN KEY (nidn) REFERENCES dosen(nidn) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE nilai_mutu (
    nilai_huruf VARCHAR(2) PRIMARY KEY,
    nilai_mutu DECIMAL(3,2) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE rencana_studi (
    id_rencana_studi INT AUTO_INCREMENT PRIMARY KEY,
    nim VARCHAR(20) NOT NULL,
    id_jadwal INT NOT NULL,
    nilai_angka DECIMAL(5,2) DEFAULT NULL,
    nilai_huruf VARCHAR(2) DEFAULT NULL,
    FOREIGN KEY (nim) REFERENCES mahasiswa(nim) ON DELETE CASCADE,
    FOREIGN KEY (id_jadwal) REFERENCES jadwal(id) ON DELETE CASCADE,
    FOREIGN KEY (nilai_huruf) REFERENCES nilai_mutu(nilai_huruf) ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE user (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    nama_user VARCHAR(50) NOT NULL,
    role ENUM('admin', 'mahasiswa', 'dosen') NOT NULL,
    kode_peran VARCHAR(20) NOT NULL
) ENGINE=InnoDB;

-- Insert sample data
INSERT INTO mahasiswa (nim, nama) VALUES
('12345', 'Ahmad'),
('67890', 'Budi'),
('11111', 'Cici');

INSERT INTO dosen (nidn, nama) VALUES
('D001', 'Dr. Siti'),
('D002', 'Prof. Ali');

INSERT INTO mata_kuliah (id_mata_kuliah, kode_mata_kuliah, nama_mata_kuliah, sks) VALUES
(1, 'MK001', 'Matematika', 3),
(2, 'MK002', 'Fisika', 4),
(3, 'MK003', 'Kimia', 2);

INSERT INTO ruangan (id_ruangan, nama_ruangan) VALUES
(1, 'Ruang A'),
(2, 'Ruang B');

INSERT INTO jadwal (id, nama_kelas, id_mata_kuliah, id_ruangan, nidn, hari, jam) VALUES
(1, 'Kelas A', 1, 1, 'D001', 'Senin', '08:00-10:00'),
(2, 'Kelas B', 2, 2, 'D002', 'Selasa', '10:00-12:00'),
(3, 'Kelas C', 3, 1, 'D001', 'Rabu', '13:00-15:00');

INSERT INTO nilai_mutu (nilai_huruf, nilai_mutu) VALUES
('A', 4.00),
('B', 3.00),
('C', 2.00),
('D', 1.00),
('E', 0.00);

INSERT INTO user (id_user, nama_user, role, kode_peran) VALUES
(1, 'admin', 'admin', 'ADM'),
(2, 'ahmad', 'mahasiswa', 'MHS'),
(3, 'budi', 'mahasiswa', 'MHS'),
(4, 'siti', 'dosen', 'DSN'),
(5, 'ali', 'dosen', 'DSN');